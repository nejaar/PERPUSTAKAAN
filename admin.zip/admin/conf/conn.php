<?php
mysql_connect('localhost','root','') or die('Connect Failed !!!');
mysql_select_db('impal') or die('Database Not Found !!!');

?>