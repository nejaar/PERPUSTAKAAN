<?php
include "../../conf/conn.php";
$kode_buku = $_GET['kode_buku'];
$query = ("DELETE FROM buku WHERE kode_buku ='$kode_buku'");
if(!mysql_query($query)){
die(mysql_error());
}else{
echo '<script>alert("Data Berhasil Dihapus !!!");
window.location.href="../../index.php?page=buku"</script>';
}
?>