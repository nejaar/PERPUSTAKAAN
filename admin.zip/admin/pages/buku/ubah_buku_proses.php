<?php
include "../../conf/conn.php";
if($_POST)
{
$kode_buku = $_POST['kode_buku'];
$judul = $_POST['judul'];
$kategori = $_POST['kategori'];
$penerbit = $_POST['penerbit'];
$penulis = $_POST['penulis'];
$thn_terbit = $_POST['thn_terbit'];
$sinopsis = $_POST['sinopsis'];
$query = ("UPDATE buku SET judul='$judul' ,kategori='$kategori' ,penerbit='$penerbit' ,penulis='$penulis',thn_terbit='$thn_terbit',sinopsis='$sinopsis' WHERE kode_buku ='$kode_buku'");
if(!mysql_query($query)){
die(mysql_error());
}else{
echo '<script>alert("Data Berhasil Diubah !!!");
window.location.href="../../index.php?page=buku"</script>';
}
}
?>