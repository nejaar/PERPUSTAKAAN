<?php
$query = mysql_query("SELECT * FROM buku WHERE kode_buku='".$_GET['kode_buku']."'");
$row = mysql_fetch_array($query);
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      UBAH BUKU
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> HOME</a></li>
        <li class="active">UBAH BUKU</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="pages/buku/ubah_buku_proses.php">
              <div class="box-body">
                <input type="hidden" name="kode_buku" value="<?php echo $row['kode_buku']; ?>">
                <div class="form-group">
                  <label>Judul</label>
                  <input type="text" name="judul" class="form-control" placeholder="judul" value="<?php echo $row['judul']; ?>" required>
                </div>
                <div class="form-group">
                  <label>Kategori</label>
                  <select class="form-control" name="kategori">
                    <option value="<?php echo $row['kategori']; ?>">- <?php echo $row['kategori']; ?> -</option>
                    <option value="Umum">Umum</option>
                    <option value="Filsafat dan Psikologi">Filsafat dan Psikologi</option>
                    <option value="Agama">Agama</option>
                    <option value="Sosial">Sosial</option>
                    <option value="Bahasa">Bahasa</option>
                    <option value="Sains dan Matematika">Sains dan Matematika</option>
                    <option value="Teknologi">Teknologi</option>
                    <option value="Seni dan Rekreasi">Seni dan Rekreasi</option>
                    <option value="Literartur dan Sastra">Literartur dan Sastra</option>
                    <option value="Sejarah dan Geografi">Sejarah dan Geografi</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Penerbit</label>
                  <input type="text" name="penerbit" class="form-control" placeholder="penerbit" value="<?php echo $row['penerbit']; ?>" required>
                </div>
                <div class="form-group">
                  <label>Penulis</label>
                  <input type="text" name="penulis" class="form-control" placeholder="penulis" value="<?php echo $row['penulis']; ?>" required>
                </div>
                <div class="form-group">
                  <label>Tahun Terbit</label>
                  <select class="form-control" name="thn_terbit">
                    <option value="<?php echo $row['thn_terbit']; ?>">- <?php echo $row['thn_terbit']; ?> -</option>
                    <option value="2000">2000</option>
                    <option value="2001">2001</option>
                    <option value="2002">2002</option>
                    <option value="2003">2003</option>
                    <option value="2004">2004</option>
                    <option value="2005">2005</option>
                    <option value="2006">2006</option>
                    <option value="2007">2007</option>
                    <option value="2008">2008</option>
                    <option value="2009">2009</option>
                    <option value="2010">2010</option>
                    <option value="2011">2011</option>
                    <option value="2012">2012</option>
                    <option value="2013">2013</option>
                    <option value="2014">2014</option>
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Sinopsis</label>
                  <textarea type="text" name="sinopsis" class="form-control" placeholder="sinopsis" value="<?php echo $row['sinopsis']; ?>" required><?php echo $row['sinopsis']; ?></textarea>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="glyphicon glyphicon-floppy-disk"></i> Simpan</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->