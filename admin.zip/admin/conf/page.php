<?php
if(isset($_GET['page'])){
  $page = $_GET['page'];
switch ($page) {
// Beranda
  case 'buku':
    include 'pages/buku/buku.php';
    break;
  case 'tambah_buku':
	include 'pages/buku/tambah_buku.php';
	break;
  case 'ubah_buku';
	include 'pages/buku/ubah_buku.php';
	break;
  }
}else{
    include "pages/beranda.php";
  }
?>