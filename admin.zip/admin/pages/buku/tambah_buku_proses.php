<?php
include "../../conf/conn.php";
if($_POST)
{
$kode_buku = $_POST['kode_buku'];
$judul = $_POST['judul'];
$kategori = $_POST['kategori'];
$penerbit = $_POST['penerbit'];
$penulis = $_POST['penulis'];
$thn_terbit = $_POST['thn_terbit'];
$sinopsis = $_POST['sinopsis'];
$query = ("INSERT INTO buku(kode_buku,judul,kategori,penerbit,penulis,thn_terbit,sinopsis) VALUES ('".$kode_buku."','".$judul."','".$kategori."','".$penerbit."','".$penulis."','".$thn_terbit."','".$sinopsis."')");
if(!mysql_query($query)){
die(mysql_error());
}else{
echo '<script>alert("Data Berhasil Ditambahkan !!!");
window.location.href="../../index.php?page=buku"</script>';
}
}
?>